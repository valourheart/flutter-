import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(debugShowCheckedModeBanner: false, home: MarkPage()));
}

class MarkPage extends StatefulWidget {
  const MarkPage({super.key});

  @override
  State<MarkPage> createState() => _MarkPageState();
}

class _MarkPageState extends State<MarkPage> {
  final m1 = TextEditingController();
  final m2 = TextEditingController();
  final m3 = TextEditingController();

  String result = '';

  void calculate() {
    double a = double.tryParse(m1.text) ?? -1;
    double b = double.tryParse(m2.text) ?? -1;
    double c = double.tryParse(m3.text) ?? -1;

    setState(() {
      if (a < 0 || a > 100 || b < 0 || b > 100 || c < 0 || c > 100) {
        result = 'Enter valid marks!';
      } else {
        double total = a + b + c;
        double percentage = total / 3;

        result =
            'Total: $total / 300\nPercentage: ${percentage.toStringAsFixed(2)}%';
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Mark Calculator')),
      body: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          children: [
            TextField(
              controller: m1,
              decoration: InputDecoration(labelText: 'Subject 1'),
            ),
            TextField(
              controller: m2,
              decoration: InputDecoration(labelText: 'Subject 2'),
            ),
            TextField(
              controller: m3,
              decoration: InputDecoration(labelText: 'Subject 3'),
            ),
            ElevatedButton(onPressed: calculate, child: Text('Calculate')),
            Text(result),
          ],
        ),
      ),
    );
  }
}
