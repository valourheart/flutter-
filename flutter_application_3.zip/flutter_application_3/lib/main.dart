import 'package:flutter/material.dart';

void main() {
  runApp(
    const MaterialApp(debugShowCheckedModeBanner: false, home: ProductPage()),
  );
}

class Product {
  final String name;
  final int price, quantity;

  const Product(this.name, this.price, this.quantity);
}

class ProductPage extends StatelessWidget {
  const ProductPage({super.key});

  final List<Product> products = const [
    Product('Apple Laptop', 100000, 5),
    Product('HP Laptop', 80000, 3),
    Product('iPhone 16', 70000, 6),
    Product('Samsung Mobile', 50000, 2),
    Product('Smart TV', 45000, 10),
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Product Shopping App'),
        backgroundColor: Colors.deepPurple,
      ),

      body: ListView.builder(
        itemCount: products.length,
        itemBuilder: (context, index) {
          final p = products[index];

          return ListTile(
            leading: CircleAvatar(child: Text(p.name[0])),

            title: Text(p.name),

            subtitle: Text('Price: ₹${p.price} | Quantity: ${p.quantity}'),

            onTap: () {
              ScaffoldMessenger.of(context)
                  .showSnackBar(SnackBar(content: Text(p.name)));
            },

            trailing: ElevatedButton(
              child: const Text('Order More'),
              onPressed: () {
                showDialog(
                  context: context,
                  builder: (context) => AlertDialog(
                    title: Text(p.name),
                    content: Text(
                      'Price: ₹${p.price}\n'
                      'Quantity: ${p.quantity}\n'
                      'Total: ₹${p.price * p.quantity}',
                    ),
                    actions: [
                      TextButton(
                        onPressed: () {
                          Navigator.pop(context);

                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text(
                                '${p.name} order placed successfully!',
                              ),
                            ),
                          );
                        },
                        child: const Text('OK'),
                      ),
                    ],
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }
}
