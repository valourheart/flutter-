import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(home: StudentPage()));
}

// FIRST SCREEN
class StudentPage extends StatelessWidget {
  final name = TextEditingController();
  final reg = TextEditingController();
  final m1 = TextEditingController();
  final m2 = TextEditingController();
  final m3 = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Student Details')),
      body: Column(
        children: [
          TextField(
            controller: name,
            decoration: InputDecoration(labelText: 'Name'),
          ),
          TextField(
            controller: reg,
            decoration: InputDecoration(labelText: 'Register No'),
          ),
          TextField(
            controller: m1,
            decoration: InputDecoration(labelText: 'Mark 1'),
          ),
          TextField(
            controller: m2,
            decoration: InputDecoration(labelText: 'Mark 2'),
          ),
          TextField(
            controller: m3,
            decoration: InputDecoration(labelText: 'Mark 3'),
          ),

          ElevatedButton(
            child: Text('Submit'),
            onPressed: () {
              double total =
                  double.parse(m1.text) +
                  double.parse(m2.text) +
                  double.parse(m3.text);

              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => ResultPage(name.text, reg.text, total),
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}

// SECOND SCREEN
class ResultPage extends StatelessWidget {
  final String name, reg;
  final double total;

  ResultPage(this.name, this.reg, this.total);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Student Result')),
      body: Column(
        children: [
          Text('Name: $name'),
          Text('Register No: $reg'),
          Text('Total: $total'),
          Text('Average: ${total / 3}'),
          Text('Percentage: ${total / 3}%'),

          ElevatedButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Go Back'),
          ),
        ],
      ),
    );
  }
}
