import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

void main() => runApp(MaterialApp(home: StudentPage()));

class StudentPage extends StatefulWidget {
  @override
  State<StudentPage> createState() => _StudentPageState();
}

class _StudentPageState extends State<StudentPage> {
  Database? db;
  final name = TextEditingController();
  final reg = TextEditingController();
  final dept = TextEditingController();
  final marks = TextEditingController();
  List students = [];

  Future<void> initDB() async {
    db = await openDatabase(
      join(await getDatabasesPath(), 'student.db'),
      version: 1,
      onCreate: (db, v) => db.execute(
        'CREATE TABLE students(id INTEGER PRIMARY KEY, name TEXT, reg TEXT, dept TEXT, marks TEXT)',
      ),
    );
    loadData();
  }

  Future<void> loadData() async {
    students = await db!.query('students');
    setState(() {});
  }

  Future<void> saveData() async {
    if (name.text.isEmpty ||
        reg.text.isEmpty ||
        dept.text.isEmpty ||
        marks.text.isEmpty) return;

    await db!.insert('students', {
      'name': name.text,
      'reg': reg.text,
      'dept': dept.text,
      'marks': marks.text,
    });

    name.clear();
    reg.clear();
    dept.clear();
    marks.clear();
    loadData();
  }

  @override
  void initState() {
    super.initState();
    initDB();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Student Records')),
      body: ListView(
        padding: EdgeInsets.all(15),
        children: [
          for (var item in [
            [name, 'Name'],
            [reg, 'Register Number'],
            [dept, 'Department'],
            [marks, 'Marks']
          ])
            TextField(
              controller: item[0] as TextEditingController,
              decoration: InputDecoration(labelText: item[1] as String),
            ),
          ElevatedButton(
            onPressed: saveData,
            child: Text('Save Student'),
          ),
          Text('Saved Records', style: TextStyle(fontSize: 20)),
          for (var s in students)
            ListTile(
              title: Text(s['name']),
              subtitle: Text(
                '${s['reg']} - ${s['dept']} - ${s['marks']}',
              ),
            ),
        ],
      ),
    );
  }
}
