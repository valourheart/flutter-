import 'package:flutter/material.dart';

void main() {
  runApp(
    const MaterialApp(debugShowCheckedModeBanner: false, home: FruitPage()),
  );
}

class FruitPage extends StatelessWidget {
  const FruitPage({super.key});

  final fruits = const [
    [
      'Apple',
      '₹150.00',
      'https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?w=300',
    ],
    [
      'Orange',
      '₹120.00',
      'https://images.unsplash.com/photo-1547514701-42782101795e?w=300',
    ],
    [
      'Mango',
      '₹70.00',
      'https://images.unsplash.com/photo-1553279768-865429fa0078?w=300',
    ],
    [
      'Pomegranate',
      '₹250.00',
      'https://images.unsplash.com/photo-1541344999736-5a1c4f2b?auto=format&w=300',
    ],
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Custom List View'),
        centerTitle: true,
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
      ),

      body: ListView.builder(
        itemCount: fruits.length,
        itemBuilder: (context, index) {
          return Card(
            elevation: 3,
            margin: const EdgeInsets.all(10),
            child: SizedBox(
              height: 125,
              child: Row(
                children: [
                  Image.network(
                    fruits[index][2],
                    width: 115,
                    height: 125,
                    fit: BoxFit.cover,
                  ),

                  Expanded(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          fruits[index][0],
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 17,
                          ),
                        ),

                        Text(fruits[index][1]),

                        ElevatedButton(
                          onPressed: () {},
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.deepPurple,
                            foregroundColor: Colors.white,
                          ),
                          child: const Text('Buy Now'),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
